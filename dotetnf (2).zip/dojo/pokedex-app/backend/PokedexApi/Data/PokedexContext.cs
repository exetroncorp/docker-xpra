using Microsoft.EntityFrameworkCore;
using PokedexApi.Models;

namespace PokedexApi.Data
{
    public class PokedexContext : DbContext
    {
        public PokedexContext(DbContextOptions<PokedexContext> options)
            : base(options) { }

        public DbSet<Pokemon> Pokemons { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Données initiales
            modelBuilder.Entity<Pokemon>().HasData(
                new Pokemon { Id = 1, Name = "Pikachu", Type = "Electric", Level = 25 },
                new Pokemon { Id = 2, Name = "Bulbasaur", Type = "Grass/Poison", Level = 15 },
                new Pokemon { Id = 3, Name = "Charmander", Type = "Fire", Level = 18 }
            );
        }
    }
}