import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Pokemon } from '../../models/pokemon';
import { PokemonService } from '../../services/pokemon';

@Component({
  selector: 'app-pokemon-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './pokemon-list.html',
  styleUrls: ['./pokemon-list.css']
})
export class PokemonListComponent implements OnInit {
  pokemons: Pokemon[] = [];
  newPokemon: Pokemon = { id: 0, name: '', type: '', level: 1 };
  editingPokemon: Pokemon | null = null;

  constructor(private pokemonService: PokemonService) {}

  ngOnInit(): void {
    this.loadPokemons();
  }

  loadPokemons(): void {
    this.pokemonService.getAll().subscribe(data => {
      this.pokemons = data;
    });
  }

  addPokemon(): void {
    this.pokemonService.create(this.newPokemon).subscribe(() => {
      this.loadPokemons();
      this.newPokemon = { id: 0, name: '', type: '', level: 1 };
    });
  }

  editPokemon(pokemon: Pokemon): void {
    this.editingPokemon = { ...pokemon };
  }

  updatePokemon(): void {
    if (this.editingPokemon) {
      this.pokemonService.update(this.editingPokemon.id, this.editingPokemon)
        .subscribe(() => {
          this.loadPokemons();
          this.editingPokemon = null;
        });
    }
  }

  deletePokemon(id: number): void {
    if (confirm('Supprimer ce Pokémon ?')) {
      this.pokemonService.delete(id).subscribe(() => {
        this.loadPokemons();
      });
    }
  }

  cancelEdit(): void {
    this.editingPokemon = null;
  }
}
