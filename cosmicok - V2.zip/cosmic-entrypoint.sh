#!/bin/bash
set -e

echo "?? D�marrage environnement COSMIC-style..."

# Variables
export USER_HOME=/home/devuser
export XDG_RUNTIME_DIR=/tmp/runtime-devuser
export HOME=$USER_HOME
export DISPLAY=:100
export USER=devuser

# Cr�er r�pertoires avec bonnes permissions
mkdir -p $XDG_RUNTIME_DIR /tmp/xpra /tmp/.X11-unix
chmod 1777 /tmp/.X11-unix
chmod 700 $XDG_RUNTIME_DIR
chown -R devuser:devuser $XDG_RUNTIME_DIR $USER_HOME

# D-Bus
echo "?? Configuration D-Bus..."
export DBUS_SESSION_BUS_ADDRESS="unix:path=$XDG_RUNTIME_DIR/bus"
gosu devuser dbus-daemon --session --address=$DBUS_SESSION_BUS_ADDRESS --nofork --nopidfile --nosyslog &
DBUS_PID=$!
sleep 3

# Script de d�marrage des applications
cat > $USER_HOME/start-cosmic-apps.sh << 'EOF'
#!/bin/bash
export DISPLAY=:100
export HOME=/home/devuser
export XDG_RUNTIME_DIR=/tmp/runtime-devuser

# Attendre que X soit pr�t
echo "Attente du serveur X..."
timeout=60
counter=0
while ! xdpyinfo >/dev/null 2>&1; do
    sleep 1
    counter=$((counter + 1))
    if [ $counter -gt $timeout ]; then
        echo "ERREUR: Timeout en attendant le serveur X"
        exit 1
    fi
done
echo "Serveur X pr�t!"

echo "D�marrage des applications COSMIC-style..."

# Fond d'�cran couleur unie (style COSMIC)
xsetroot -solid '#2d2d2d' &

# D�marrer PCManFM pour g�rer le bureau
pcmanfm --desktop --no-desktop-conf &
sleep 2

# Cr�er des ic�nes de bureau
mkdir -p $HOME/Desktop

cat > $HOME/Desktop/Terminal.desktop << 'TERMINAL_EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Terminal
Comment=COSMIC Terminal
Exec=xterm -bg '#2d2d2d' -fg '#ffffff' -fa 'DejaVu Sans Mono' -fs 12 -title "COSMIC Terminal"
Icon=utilities-terminal
Terminal=false
Categories=System;TerminalEmulator;
TERMINAL_EOF

cat > $HOME/Desktop/Firefox.desktop << 'FIREFOX_EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Firefox
Comment=Web Browser
Exec=firefox
Icon=firefox
Terminal=false
Categories=Network;WebBrowser;
FIREFOX_EOF

cat > $HOME/Desktop/Files.desktop << 'FILES_EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=File Manager
Comment=Browse files
Exec=thunar
Icon=folder
Terminal=false
Categories=System;FileTools;FileManager;
FILES_EOF

# Rendre les fichiers desktop ex�cutables
chmod +x $HOME/Desktop/*.desktop

# D�marrer un terminal par d�faut avec style COSMIC
xterm -bg '#2d2d2d' -fg '#ffffff' -fa 'DejaVu Sans Mono' -fs 12 \
      -geometry 80x24+100+100 -title "COSMIC Terminal" &

# D�marrer gestionnaire de fichiers
sleep 2
thunar &

# Panel/barre en haut avec plus d'informations (style COSMIC)
sleep 1
(
  while true; do
    # Date et heure
    datetime=$(date +'%a %b %d, %H:%M')
    
    # Informations syst�me basiques
    load=$(cat /proc/loadavg | cut -d' ' -f1)
    
    # Cr�er la barre d'�tat
    status="COSMIC Desktop     |     Load: $load     |     $datetime"
    echo "$status"
    sleep 30
  done
) | dzen2 -p -ta c -bg '#1a1a1a' -fg '#ffffff' -fn 'DejaVu Sans Mono-9' \
          -x 0 -y 0 -w 1920 -h 30 &

# Notification de d�marrage
(
  sleep 5
  echo "COSMIC Desktop Ready!" | dzen2 -p -ta c -bg '#4a90e2' -fg '#ffffff' \
                                       -fn 'DejaVu Sans Mono-12' \
                                       -x 660 -y 400 -w 600 -h 60 -t 5
) &

# Maintenir le script en vie
sleep infinity
EOF

chmod +x $USER_HOME/start-cosmic-apps.sh
chown devuser:devuser $USER_HOME/start-cosmic-apps.sh

# Nettoyage
cleanup() {
    echo "?? Arr�t..."
    kill $DBUS_PID 2>/dev/null || true
    gosu devuser xpra stop :100 2>/dev/null || true
    exit 0
}
trap cleanup SIGTERM SIGINT

# Cr�er le r�pertoire socket pour Xpra
mkdir -p /run/user/1001/xpra
chown devuser:devuser /run/user/1001/xpra
chmod 755 /run/user/1001/xpra

# D�marrage Xpra avec configuration corrig�e
echo "??? D�marrage Xpra en mode seamless..."
exec gosu devuser xpra start :100 \
    --bind-tcp=0.0.0.0:14500 \
    --html=on \
    --daemon=no \
    --start="/home/devuser/start-cosmic-apps.sh" \
    --exit-with-children=no \
    --encoding=auto \
    --quality=80 \
    --speed=85 \
    --compression-level=1 \
    --compressors=lz4,lzo \
    --speaker=off \
    --microphone=off \
    --clipboard=both \
    --file-transfer=on \
    --opengl=off \
    --mdns=no \
    --printing=no \
    --pulseaudio=no \
    --systemd-run=no \
    --socket-dirs=/tmp/runtime-devuser \
    --log-dir=/tmp \
    --debug=keyboard,screen