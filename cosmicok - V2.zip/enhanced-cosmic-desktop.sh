#!/bin/bash
export DISPLAY=:100
export HOME=/home/devuser
export XDG_RUNTIME_DIR=/tmp/runtime-devuser

# Attendre que X soit pr�t
echo "Attente du serveur X..."
while ! xdpyinfo >/dev/null 2>&1; do
    sleep 1
done
echo "Serveur X pr�t!"

echo "D�marrage des applications COSMIC-style avec bureau complet..."

# Cr�er les r�pertoires n�cessaires
mkdir -p $HOME/Desktop $HOME/.config/autostart $HOME/.local/share/applications

# Fond d'�cran couleur unie (style COSMIC)
xsetroot -solid '#2d2d2d' &

# Installer et configurer pcmanfm comme gestionnaire de bureau
# Cr�er le fichier de configuration pour pcmanfm
mkdir -p $HOME/.config/pcmanfm/default
cat > $HOME/.config/pcmanfm/default/pcmanfm.conf << 'PCMANFM_EOF'
[config]
bm_open_method=0
su_cmd=gksudo %s
terminal=xterm
archiver=file-roller
volume_manager=udisks

[volume]
mount_on_startup=1
mount_removable=1
autorun=1

[ui]
always_show_tabs=0
max_tab_chars=32
win_width=640
win_height=480
splitter_pos=150
media_in_new_tab=0
desktop_wallpaper=#2d2d2d
wallpaper_mode=2
show_hidden=0
sort=name;ascending;
toolbar=newtab;navigation;home;
show_statusbar=1
pathbar_mode_buttons=0

[desktop]
wallpaper_mode=2
wallpaper_common=1
wallpaper=#2d2d2d
desktop_bg=#2d2d2d
desktop_fg=#ffffff
desktop_shadow=#000000
show_wm_menu=0
sort=mtime;ascending;
show_documents=1
show_trash=1
show_mounts=1
PCMANFM_EOF

# Cr�er des ic�nes de bureau
cat > $HOME/Desktop/Terminal.desktop << 'TERMINAL_EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Terminal
Comment=COSMIC Terminal
Exec=xterm -bg '#2d2d2d' -fg '#ffffff' -fa 'DejaVu Sans Mono' -fs 12 -title "COSMIC Terminal"
Icon=utilities-terminal
Terminal=false
Categories=System;TerminalEmulator;
TERMINAL_EOF

cat > $HOME/Desktop/Firefox.desktop << 'FIREFOX_EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Firefox
Comment=Web Browser
Exec=firefox
Icon=firefox
Terminal=false
Categories=Network;WebBrowser;
FIREFOX_EOF

cat > $HOME/Desktop/File\ Manager.desktop << 'FILES_EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=File Manager
Comment=Browse files
Exec=thunar
Icon=folder
Terminal=false
Categories=System;FileTools;FileManager;
FILES_EOF

cat > $HOME/Desktop/Text\ Editor.desktop << 'EDITOR_EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Text Editor
Comment=Edit text files
Exec=gedit
Icon=text-editor
Terminal=false
Categories=Utility;TextEditor;
EDITOR_EOF

# Rendre les fichiers desktop ex�cutables
chmod +x $HOME/Desktop/*.desktop

# D�marrer PCManFM en mode bureau (gestion des ic�nes de bureau)
pcmanfm --desktop --no-desktop-conf &
sleep 2

# D�marrer un terminal par d�faut avec style COSMIC
xterm -bg '#2d2d2d' -fg '#ffffff' -fa 'DejaVu Sans Mono' -fs 12 \
      -geometry 80x24+100+100 -title "COSMIC Terminal" &

# D�marrer gestionnaire de fichiers en fen�tre
sleep 2
thunar &

# Panel/barre en haut avec plus d'informations (style COSMIC)
sleep 1
(
  while true; do
    # Date et heure
    datetime=$(date +'%a %b %d, %H:%M')
    
    # Informations syst�me
    load=$(cat /proc/loadavg | cut -d' ' -f1)
    mem=$(free -m | grep "Mem:" | awk '{printf "%.0f%%", $3/$2 * 100.0}')
    
    # Cr�er la barre d'�tat
    status="COSMIC Desktop     |     Load: $load     |     Memory: $mem     |     $datetime"
    echo "$status"
    sleep 10
  done
) | dzen2 -p -ta c -bg '#1a1a1a' -fg '#ffffff' -fn 'DejaVu Sans Mono-9' \
          -x 0 -y 0 -w 1920 -h 30 &

# Menu d'applications simple (clic droit simul�)
(
  while true; do
    echo "Applications | Terminal | Firefox | Files | Settings"
    sleep 60
  done
) | dzen2 -p -ta l -bg '#333333' -fg '#ffffff' -fn 'DejaVu Sans Mono-8' \
          -x 0 -y 30 -w 1920 -h 25 -e 'button1=exec:dmenu_run' &

# Lanceur d'applications avec dmenu (Alt+F2 �quivalent)
# Cr�er un script pour le lanceur
cat > $HOME/.local/bin/cosmic-launcher << 'LAUNCHER_EOF'
#!/bin/bash
APP=$(dmenu -nb '#2d2d2d' -nf '#ffffff' -sb '#4a90e2' -sf '#ffffff' \
           -fn 'DejaVu Sans Mono-10' -p 'Run:' < /dev/null)
if [ -n "$APP" ]; then
    $APP &
fi
LAUNCHER_EOF
chmod +x $HOME/.local/bin/cosmic-launcher

# Cr�er un dock simple en bas
(
  while true; do
    echo "?? ?? ?? ??   |   $(date +'%H:%M')"
    sleep 30
  done
) | dzen2 -p -ta c -bg '#1a1a1a' -fg '#ffffff' -fn 'DejaVu Sans Mono-10' \
          -x 0 -y -35 -w 1920 -h 35 -e 'button1=exec:thunar;button3=exec:dmenu_run' &

# Gestionnaire de fen�tres simple avec touches
(
  sleep 5
  # Configurer quelques raccourcis clavier basiques
  xbindkeys -n &
) &

# Cr�er configuration xbindkeys pour les raccourcis
cat > $HOME/.xbindkeysrc << 'XBIND_EOF'
# Lanceur d'applications
"dmenu_run -nb '#2d2d2d' -nf '#ffffff' -sb '#4a90e2' -sf '#ffffff'"
    alt + F2

# Terminal
"xterm -bg '#2d2d2d' -fg '#ffffff' -fa 'DejaVu Sans Mono' -fs 12"
    ctrl + alt + t

# Gestionnaire de fichiers
"thunar"
    super + e
XBIND_EOF

# Notification de d�marrage
(
  sleep 3
  echo "COSMIC Desktop Ready!" | dzen2 -p -ta c -bg '#4a90e2' -fg '#ffffff' \
                                       -fn 'DejaVu Sans Mono-12' \
                                       -x 660 -y 400 -w 600 -h 60 -t 3
) &

# Maintenir le script en vie
sleep infinity